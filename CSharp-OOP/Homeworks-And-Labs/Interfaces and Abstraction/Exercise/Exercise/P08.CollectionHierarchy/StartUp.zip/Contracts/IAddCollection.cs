﻿namespace P08.CollectionHierarchy.Contracts
{
    public interface IAddCollection
    {
        int Add(string item);
    }
}
