﻿namespace P08.CollectionHierarchy.Contracts
{
    interface IMyList : IAddRemoveCollection
    {
        int Used { get; }
    }
}
