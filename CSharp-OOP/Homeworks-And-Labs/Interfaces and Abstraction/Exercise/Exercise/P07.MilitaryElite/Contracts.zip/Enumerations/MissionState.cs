﻿namespace P07.MilitaryElite.Enumerations
{
    public enum MissionState
    {
        inProgress = 1,
        Finished = 2
    }
}
