﻿namespace P03.Telephony
{
    public interface IBrowsable
    {
        string Browse(string site);
    }
}
