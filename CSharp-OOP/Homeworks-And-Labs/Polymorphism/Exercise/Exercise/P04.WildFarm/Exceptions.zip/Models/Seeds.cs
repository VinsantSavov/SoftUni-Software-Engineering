﻿namespace P04.WildFarm.Models
{
    public class Seeds : Food
    {
        public Seeds(int quantity)
            : base(quantity)
        {
        }
    }
}
