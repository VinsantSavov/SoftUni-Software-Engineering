﻿namespace P04.WildFarm.Models.Contracts
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
