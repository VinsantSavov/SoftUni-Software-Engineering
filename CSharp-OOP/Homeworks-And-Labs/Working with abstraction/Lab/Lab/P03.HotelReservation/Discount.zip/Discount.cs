﻿namespace P03.HotelReservation
{
    public enum Discount
    {
        VIP = 20,
        SecondVisit = 10,
        None = 0
    }
}
