﻿namespace DataLogger.Models.Contracts
{
    public interface ILayout
    {
        string Format { get; }
    }
}
