﻿namespace DataLogger.Core
{
    public interface IEngine
    {
        void Run();
    }
}
