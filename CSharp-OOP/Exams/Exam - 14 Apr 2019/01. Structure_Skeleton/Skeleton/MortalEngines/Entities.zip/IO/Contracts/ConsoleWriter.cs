﻿namespace MortalEngines.IO.Contracts
{
    public class ConsoleWriter
    {
        public void WriteLine(string message)
        {
            System.Console.WriteLine(message);
        }
    }
}
