﻿namespace SantaWorkshop.Repositories
{
    public interface IRepository
    {
    }
}