﻿using System;

namespace P02.LibraryIterator
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
