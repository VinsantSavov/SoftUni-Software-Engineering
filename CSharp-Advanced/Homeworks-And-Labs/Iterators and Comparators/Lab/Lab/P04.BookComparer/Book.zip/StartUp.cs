﻿using System;

namespace P04.BookComparer
{
    class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
