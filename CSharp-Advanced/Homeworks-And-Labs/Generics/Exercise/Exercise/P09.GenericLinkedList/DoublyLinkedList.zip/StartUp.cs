﻿using System;

namespace P09.GenericLinkedList
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
